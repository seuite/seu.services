<?php
header('Content-Type: text/plain; charset=utf-8');
echo $_SERVER['REMOTE_ADDR'];
?>
